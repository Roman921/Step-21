<div class="gmpMarkerListIconItem">
	<img src="<?php echo $this->marker['icon_data']['path'];?>" />
</div>
