<?php
class userControllerGmp extends controllerGmp {
	
}
