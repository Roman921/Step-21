<div class="gmpAdminFooterShell">
	<div class="gmpAdminFooterCell">
		<?php echo GMP_WP_PLUGIN_NAME?>
		<?php langGmp::_e('Version')?>:
		<a target="_blank" href="<?php echo $this->getModule()->preparePromoLink('http://readyshoppingcart.com/product/google-maps-plugin/');?>"><?php echo GMP_VERSION?></a>
	</div>
	<div class="gmpAdminFooterCell">|</div>

	
	<div class="gmpAdminFooterCell">
		<a target="_blank" href=" http://wordpress.org/support/plugin/google-maps-ready"><?php langGmp::_e('Support')?></a>
	</div>
	<div class="gmpAdminFooterCell">|</div>
	<div class="gmpAdminFooterCell">
		Add your <a target="_blank" href="https://wordpress.org/support/view/plugin-reviews/google-maps-ready?rate=5#postform">&#9733;&#9733;&#9733;&#9733;&#9733;</a> on wordpress.org.
	</div>
</div>