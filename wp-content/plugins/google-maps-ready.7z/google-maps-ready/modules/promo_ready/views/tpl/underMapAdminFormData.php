<?php /*Epty for now*/ ?>
<?php /*?>
<div class="gmpUnderMapPic">
	<div class="gmp-pic-title">
		<h4><a target="_blank"  href="http://readyshoppingcart.com/product/google-maps-plugin/"><?php langGmp::_e('PRO version img');?></a></h4>	
	</div>
	<div class="gmp-undermap-pic">
		<a target="_blank"  href="http://readyshoppingcart.com/product/google-maps-plugin/">
			<img src='<?php echo GMP_IMG_PATH ;?>underMapPic.jpg' />
		</a>
	</div>
</div>
<?php */?>