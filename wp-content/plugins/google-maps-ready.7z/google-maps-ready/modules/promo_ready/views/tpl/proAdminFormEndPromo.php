<div class="gmpFormRow">
	<a href="<?php echo $this->proLink?>" target="_blank"><img src="<?php echo $this->modPath?>img/pro_controls_2.png" title="PRO Additional Settings" /></a>
</div>