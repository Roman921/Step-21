<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8" />
	
	<title>Theme Title</title>
	
	<!-- STYLES -->
	<link type="text/css" rel="stylesheet" media="all" href="<?php bloginfo('template_url') ?>/css/blue2.css" />
	<link type="text/css" rel="stylesheet" media="all" href="<?php bloginfo('template_url') ?>/js/prettyPhoto/css/prettyPhoto.css" />
	<!--[if IE 7]><link type="text/css" rel="stylesheet" media="screen" href="css/ie7.css" /><![endif]-->
	<!--[if IE 8]><link type="text/css" rel="stylesheet" media="screen" href="css/ie8.css" /><![endif]-->
	
	<!-- FONT -->
	<link href='http://fonts.googleapis.com/css?family=Droid+Serif:400,700' rel='stylesheet' type='text/css'>
</head>

<body class="homepage">
    <?php /* ?>
  <?php  query_posts( 'p=36' ); ?>
    <?php if(have_posts()):while (have_posts()) :the_post() ?>
<?php the_title() ?>
    
    <?php the_excerpt()?>
    
	<?php the_content()?>
    <h1><a href="<?php the_permalink() ?>"><?php the_title()?></a></h1>
<?php endwhile;?>
    
     <?php endif; ?>
    */?>
	<!-- NAVIGATION -->
	<div id="header">
		<div id="header_inner">
			<a id="logo" href="#">
				<img src="<?php bloginfo('template_url')?>/images/logo.png" alt="Logo" />
			</a>
			
			<ul id="nav">
				<li class="current-menu-item"><a href="index.html">Home</a></li>
				<li>
					<a href="about.html">About Us</a>
					<ul>
						<li><a href="columns.html">Columns</a></li>
						<li><a href="#">Lorem</a></li>
						<li>
							<a href="#">Ipsum Incididunt</a>
							<ul>
								<li><a href="#">Adispisicing</a></li>
								<li><a href="#">Dolor Consectetur</a></li>
							</ul>
						</li>
						<li><a href="#">Dolor Consectetur</a></li>
						<li><a href="#">Adispisicing</a></li>
					</ul>
				</li>
				<li>
					<a href="portfolio-3-columns.html">Portfolio</a>
					<ul>
						<li><a href="portfolio-2-columns.html">Two Columns</a></li>
						<li><a href="portfolio-3-columns.html">Three Columns</a></li>
						<li><a href="portfolio-4-columns.html">Four Columns</a></li>
						<li><a href="portfolio-quicksand-3-columns.html">Quicksand Portfolio 3 Columns</a></li>
						<li><a href="portfolio-quicksand-4-columns.html">Quicksand Portfolio 4 Columns</a></li>
					</ul>
				</li>
				<li>
					<a href="blog.html">Blog</a>
					<ul>
						<li><a href="blog.html">Blog 1</a></li>
						<li><a href="blog2.html">Blog 2</a></li>
						<li><a href="blog-post.html">Blog Post</a></li>
					</ul>
				</li>
				<li><a href="contact.html">Contact Us</a></li>
			</ul>
		</div>
	</div>
	
	<!-- CALL TO ACTION -->
	<div id="cta">
		<div id="cta_inner">
			<p class="cta_text">
				Lorem ipsum dolor sit amet, <a href="#">consectetur adipisicing</a> elit, sed do eiusmod tempor incididunt ut labore et dolore!
			</p>
			
			<a class="cta_button" href="about.html">Learn More<span></span></a>
		</div>
		<div class="shadow_bottom"></div>
	</div>
		<!-- SLIDESHOW -->
	<div id="slideshow_wrap">
		<div id="slideshow">
			<div class="slideshow_controls">
				<a class="prev" href="#" title="Previous"></a>
				<a class="start" href="#"></a>
				<a class="next" href="#" title="Next"></a>
			</div>
			
			<ul>
				<!-- slide 1 -->
				<li>
					<img src="<?php bloginfo('template_url')?>/content/1600_500/1.jpg" width="1600" height="500" alt="" />
					
				</li>
				
				<!-- slide 2 -->
				<li>
					<img src="<?php bloginfo('template_url')?>/content/1600_500/2.jpg" width="1600" height="500" alt="" />
					
				</li>
				
				<!-- slide 3 -->
				<li>
					<img src="<?php bloginfo('template_url')?>/content/1600_500/3.jpg" width="1600" height="500" alt="" />
					
				</li>
				
				<!-- slide 4 -->
				<li>
					<img src="<?php bloginfo('template_url')?>/content/1600_500/2.jpg" width="1600" height="500" alt="" />
					
				</li>
			</ul>
		</div>
		
		<div id="slideshow_shadow"></div>
	</div>
	
	
	
	<!-- FEATURED -->
	<div class="section">
		<div class="container_12">
			<h2 class="grid_12 section_title">Our Works</h2>
                        <?php query_posts('cat=2') ?>
                          <?php if(have_posts()):while (have_posts()) :the_post() ?>
			<div class="featured grid_4">
				
				<div class="framed_image">
					<img src="<?php bloginfo('template_url')?>/content/290_180/1.jpg" width="290" height="180" alt="" />
					
					<div class="lb_controls">
						<a class="lb_link" href="#" title="Link"></a>
						<a class="lb_magnify" href="content/enlarged/1.jpg" title="Picture Title"></a>
					</div>
				</div>
				<h4><?php the_title() ?></h4>
				
				<p>
					<?php the_excerpt()?>
				</p>
				
				<p>
                                    <a class="button" href="<?php the_permalink() ?>">Learn More!<span></span></a>
				</p>
			</div>
                        <?php endwhile;?>
                        <?php endif;?>
			<!--
			<div class="featured grid_4">
				<div class="framed_image">
					<img src="<?php bloginfo('template_url')?>/content/290_180/2.jpg" width="290" height="180" alt="" />
					
					<div class="lb_controls">
						<a class="lb_link" href="#" title="Link"></a>
						<a class="lb_magnify" href="content/enlarged/1.jpg" title="Picture Title"></a>
					</div>
				</div>
				
				<h4>Lorem ipsum dolor sit amet</h4>
				
				<p>
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.
				</p>
				
				<p>
					<a class="button" href="about.html">Learn More!<span></span></a>
				</p>
			</div>
			
			<div class="featured grid_4">
				<div class="framed_image">
					<img src="<?php bloginfo('template_url')?>/content/290_180/3.jpg" width="290" height="180" alt="" />
					
					<div class="lb_controls">
						<a class="lb_link" href="#" title="Link"></a>
						<a class="lb_magnify" href="content/enlarged/1.jpg" title="Picture Title"></a>
					</div>
				</div>
				
				<h4>Lorem ipsum dolor sit amet</h4>
				
				<p>
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.
				</p>
				
				<p>
					<a class="button" href="about.html">Learn More!<span></span></a>
				</p>
			</div>
			-->
			<div class="clear"></div>
		</div>
	</div>
	
	<!-- ABOUT US -->
	<div class="section grey icons_list">
		<div class="container_12">
			<h2 class="grid_12 section_title">About Us</h2>
			
			<div class="grid_12">
				<p>
					
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident.
				</p>
			</div>
			
			
			<div class="clear"></div>
		</div>
		<div class="shadow_top"></div>
		<div class="shadow_bottom"></div>
	</div>
	
	<!-- OUR WORKS -->
	<div class="section">
		<div class="container_12">
			<h2 class="grid_12 section_title">Our Partners</h2>
			
			<div class="clear"></div>
			
			<ul id="carousel">
			    <li>
			    	<img src="<?php bloginfo('template_url')?>/content/210_130/1.jpg" width="210" height="130" alt="" />
			    	
			    	
					
				
			    </li>
			    
			    <li>
			    	<img src="<?php bloginfo('template_url')?>/content/210_130/2.jpg" width="210" height="130" alt="" />
			    	
			    	
			    </li>
			    
			    <li>
			    	<img src="<?php bloginfo('template_url')?>/content/210_130/3.jpg" width="210" height="130" alt="" />
			    	
			    	
			    </li>
			    
			    <li>
			    	<img src="<?php bloginfo('template_url')?>/content/210_130/2.jpg" width="210" height="130" alt="" />
			    	
			    	
			    </li>
			    
			    <li>
			    	<img src="<?php bloginfo('template_url')?>/content/210_130/1.jpg" width="210" height="130" alt="" />
			    	
			    	
			    </li>
			    
			    <li>
			    	<img src="<?php bloginfo('template_url')?>/content/210_130/2.jpg" width="210" height="130" alt="" />
			    	
			    	
					
					<h3 class="fade_in_title">Title of the Work</h3>
			    </li>
			</ul>
		</div>
	</div>
	
	<div class="sep"></div>
	
	<!-- BLOG -->
	<div id="blog">
		<div class="container_12">
			<div class="grid_8">
				<h2>News</h2>
				
				<!-- post 1 -->
				<div class="post image_left">
					<div class="post_image">
						<!-- Simple Slideshow -->
						<ul class="dm3_slider" style="width: 210px; height: 130px;">
							<li class="slide" data-enlargeurl="content/enlarged/1.jpg">
								<img src="<?php bloginfo('template_url')?>/content/210_130/1.jpg" width="210" height="130" alt="" />
							</li>
							
							<li class="slide" data-enlargeurl="content/enlarged/2.jpg">
								<img src="<?php bloginfo('template_url')?>/content/210_130/2.jpg" width="210" height="130" alt="" />
							</li>
						</ul>
						
						<div class="lb_controls dm3_slider_nav">
							<a class="lb_link" href="#" title="Link"></a>
							<a class="lb_magnify" href="content/enlarged/1.jpg" title="Picture Title"></a>
							<a class="lb_prev dm3_prev" href="#" title="Prev"></a>
							<a class="lb_next dm3_next" href="#" title="Next"></a>
						</div>
					</div>
					
					<h3><a href="#">Lorem ipsum dolor sit amet</a></h3>
					
					<div class="post_meta">
						<span class="entry_date">23 December 2011</span>
						<span class="entry_tags"><a href="#">News</a></span>
						<span class="entry_comments">25 comments</span>
					</div>
					
					<p>
						Donec a odio massa, eget malesuada libero. Donec tempor nisl at quam imperdiet in accumsan nunc bibendum. Donec magna elit, scelerisque nec interdum ac, ullamcorper at lorem. Vestibulum cursus arcu eu lorem feugiat at rutrum erat facilisis.
					</p>
					
					<p>
						<a class="button" href="about.html">Read More!<span></span></a>
					</p>
				</div>
				
				<!-- post 2 -->
				<div class="post image_left">
					<div class="post_image">
						<a href="#">
							<img src="<?php bloginfo('template_url')?>/content/210_130/2.jpg" width="210" height="130" alt="" />
						</a>
						
						<div class="lb_controls">
							<a class="lb_link" href="#" title="Link"></a>
							<a class="lb_magnify" href="content/enlarged/1.jpg" title="Picture Title"></a>
						</div>
					</div>
					
					<h3><a href="#">Lorem ipsum dolor sit amet</a></h3>
					
					<div class="post_meta">
						<span class="entry_date">23 December 2011</span>
						<span class="entry_tags"><a href="#">News</a></span>
						<span class="entry_comments">25 comments</span>
					</div>
					
					<p>
						Donec a odio massa, eget malesuada libero. Donec tempor nisl at quam imperdiet in accumsan nunc bibendum. Donec magna elit, scelerisque nec interdum ac, ullamcorper at lorem. Vestibulum cursus arcu eu lorem feugiat at rutrum erat facilisis.
					</p>
					
					<p>
						<a class="button" href="about.html">Read More!<span></span></a>
					</p>
				</div>
				
				<div class="continue_reading">
					<a href="blog.html">Get More News &raquo;</a>
				</div>
			</div>
			
			<!-- SIDEBAR -->
			<div class="grid_4 sidebar">
				<!-- Menu widget -->
				<div class="widget">
					<h4 class="widget_title">Category Menu</h4>
					
					<ul class="widget_menu">
						<li><a href="#">Lorem Ipsum</a></li>
						<li><a href="#">Adispisicing</a></li>
						<li>
							<a href="#">Dolor</a>
							
						</li>
						<li><a href="#">Consectetur</a></li>
						<li><a href="#">Elite</a></li>
						<li><a href="#">Lorem Ipsum</a></li>
					</ul>
				</div>
				
				<!-- Testimonials widget -->
				<div class="widget">
					<h4 class="widget_title">Testimonials</h4>
					
					<ul class="testimonials">
						<!-- testimonial 1 -->
						<li class="slide">
							<p>
								Consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua?
							</p>
							
							<div class="author">
								<img class="frame" src="content/customers/1.jpg" width="40" height="40" alt="" />
								<span class="author_name">Customer One</span>
								Company One
							</div>
						</li>
						
						
					</ul>
					
				
				</div>
				
				<div class="sidebar_top"></div>
				<div class="sidebar_bottom"></div>
			</div>
			
			<div class="clear"></div>
		</div>
	</div>
	
	<!-- FOOTER -->
	<div id="footer">
		<div class="container_12">
			
			<div class="grid_4">
				<div class="widget">
					<h4>Links</h4>
					
					<ul>
						<li><a href="#">Lorem Ipsum</a></li>
						<li><a href="#">Adispisicing</a></li>
						<li><a href="#">Consectetur</a></li>
						<li><a href="#">Lorem Ipsum</a></li>
						<li><a href="#">Elite</a></li>
						<li><a href="#">Consectetur</a></li>
					</ul>
				</div>
			</div>
			<div class="grid_4">
				<div class="widget">
					<h4>About Us</h4>
					
					<div>
						
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
					</p>
				</div>
				
				
			</div>
			
		
			</div>
			<div class="grid_4">
				<div class="widget">
					<h4>Links</h4>
					
					<ul>
						<li><a href="#">Lorem Ipsum</a></li>
						<li><a href="#">Adispisicing</a></li>
						<li><a href="#">Consectetur</a></li>
						<li><a href="#">Lorem Ipsum</a></li>
						<li><a href="#">Elite</a></li>
					</ul>
				</div>
			</div>
			
			
			
			<div class="clear"></div>
			<div id="first_column_bg"></div>
		</div>
		<div id="footer_border_inner"></div>
		<div id="footer_border_outer"></div>
	</div>
	
	<!-- COPYRIGHT INFO -->
	<div id="copyright">
		<div class="container_12 clearfix">
			<p class="grid_6">&copy; <a href="#">dm3studio.com</a> &mdash; All rights reserved, 2011. <a class="scroll_to" href="body.html">top</a></p>
			
			<ul class="social_icons">
				<li>
					<a href="#" title="Facebook"><img src="<?php bloginfo('template_url')?>/images/icons/facebook.png" alt="" /></a>
				</li>
				
				<li>
					<a href="#" title="Twitter"><img src="<?php bloginfo('template_url')?>/images/icons/twitter.png" alt="" /></a>
				</li>
				
				<li>
					<a href="#" title="Rss"><img src="<?php bloginfo('template_url')?>/images/icons/rss.png" alt="" /></a>
				</li>
			</ul>
		</div>
	</div>
	


	
	<!-- JAVASCRIPTS -->
	<script type="text/javascript" src="<?php bloginfo('template_url')?>/js/jquery.min.js"></script>
	<script type="text/javascript" src="<?php bloginfo('template_url')?>/js/dm3Slideshow.jquery.js"></script>
	<script type="text/javascript" src="<?php bloginfo('template_url')?>/js/dm3FadeSlider.jquery.js"></script>
	<script type="text/javascript" src="<?php bloginfo('template_url')?>/js/jquery.jcarousel.min.js"></script>
	<script type="text/javascript" src="<?php bloginfo('template_url')?>/js/prettyPhoto/jquery.prettyPhoto.js"></script>
	<script type="text/javascript" src="<?php bloginfo('template_url')?>/js/jquery.dmTabs.js"></script>
	<script type="text/javascript" src="<?php bloginfo('template_url')?>/js/custom.js"></script>
</body>
</html>