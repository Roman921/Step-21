<?php
wp_enqueue_script( 'twentythirteen-script', get_template_directory_uri() . '/js/functions.js', array( 'jquery' ), '20150330', true );


register_nav_menus( array(
	'primary' => 'Головне',
	'menu2' => 'Меню в подвале'
) );